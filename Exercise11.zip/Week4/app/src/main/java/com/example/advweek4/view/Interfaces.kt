package com.example.advweek4.view

import android.view.View

interface StudentDetailClickListener {
    fun onStudentDetailClick(view: View)
}

interface StudentUpdateClickListener {
    fun onStudentUpdateClick(view: View)
}

interface StudentNotifClickListener {
    fun onStudentNotifClick(view: View)
}