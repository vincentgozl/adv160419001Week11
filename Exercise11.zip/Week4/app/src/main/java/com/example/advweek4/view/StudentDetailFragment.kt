package com.example.advweek4.view

import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.advweek4.R
import com.example.advweek4.databinding.FragmentStudentDetailBinding
import com.example.advweek4.databinding.StudentListItemBinding
import com.example.advweek4.viewmodel.DetailViewModel
import com.example.advweek4.viewmodel.ListViewModel
import kotlinx.android.synthetic.main.fragment_student_detail.*
import kotlinx.android.synthetic.main.fragment_student_list.*
import kotlinx.android.synthetic.main.student_list_item.*
import java.util.*
import java.util.concurrent.TimeUnit



/**
 * A simple [Fragment] subclass.
 * Use the [StudentDetailFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class StudentDetailFragment : Fragment(), StudentUpdateClickListener, StudentNotifClickListener {
    private lateinit var  viewModel: DetailViewModel
    private lateinit var dataBinding: FragmentStudentDetailBinding
    private val studentListAdapter = StudentListAdapter(arrayListOf())
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        dataBinding= DataBindingUtil.inflate(inflater,R.layout.fragment_student_detail, container, false)
        return dataBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        if (arguments != null) {
            val studentId = StudentDetailFragmentArgs.fromBundle(requireArguments()).studentId
            viewModel = ViewModelProvider(this).get(DetailViewModel::class.java)
            viewModel.fetch(studentId)
        }
        dataBinding.updateListener=this
        dataBinding.notifListener=this
        observeViewModel()
    }

    fun observeViewModel() {
            viewModel.studentLD.observe(viewLifecycleOwner, {
                dataBinding.student=it
            })
        /*
        viewModel.studentLD.observe(viewLifecycleOwner, {
            editID.setText(it.id)
            editName.setText(it.name)
            editBod.setText(it.dob)
            editPhone.setText(it.phone)
        })

         */
    }

    override fun onStudentUpdateClick(view: View) {
        val action = StudentDetailFragmentDirections.actionStudentList()
        Navigation.findNavController(view).navigate(action)
    }

    override fun onStudentNotifClick(view: View) {
//        Observable.timer(5, TimeUnit.SECONDS)
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe {
//                Log.d("Messages", "five seconds")
//                MainActivity.showNotification(student.name.toString(),
//                    "A new notification created",
//                    R.drawable.circle)
//            }
    }
}